gcc -c -o mymath.o mymath.c
gcc -c -o myprint.o myprint.c
gcc -shared -o libmylib.so mymath.c myprint.c 
gcc -L./ -lmylib -ldl -o mymain mymain.c
