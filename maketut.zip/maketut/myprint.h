
void printChar(char ch);
void printInt(int i);
