#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>
int main() {
	printf("Loading dynamic library...\n");
	dlopen("./mylib.dylib", RTLD_NOW | RTLD_GLOBAL);
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printChar('a');
	printf("\nexiting...\n");
}

