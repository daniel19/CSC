#include <stdlib.h>
#include <stdio.h>
void printChar(char ch) {
	printf("%c", ch);
}

void printInt(int i) {
	printf("%d", i);
}
